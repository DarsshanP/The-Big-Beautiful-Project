// Pixel Adventure - Game UI Logic
const API_BASE_URL = 'http://localhost:8000/api'; // Keep for future
let currentUser = null;

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎮 Pixel Adventure Initializing...');
    
    // Check which page we're on
    const currentPage = window.location.pathname;
    
    if (currentPage.includes('intro.html') || currentPage.includes('index.html')) {
        // Intro page - setup START button
        setupIntroPage();
    } else if (currentPage.includes('terms.html')) {
        initTermsPage();
    } else if (currentPage.includes('login.html')) {
        initLoginPage();
    } else if (currentPage.includes('main.html')) {
        initMainPage();
    }
    
    // Check for existing session
    checkSession();
    
    // Create pixel particles
    createPixelParticles();
    
    // Add keyboard shortcuts
    setupKeyboardShortcuts();
    
    // Add page fade-in effect
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease-in-out';
    
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// ===== INTRO PAGE SETUP =====
function setupIntroPage() {
    const startBtn = document.getElementById('startBtn');
    if (startBtn) {
        startBtn.addEventListener('click', function() {
            showLoadingScreen();
            setTimeout(() => {
                window.location.href = 'terms.html';
            }, 1500);
        });
    }
}

// ===== MAIN PAGE SETUP =====
function initMainPage() {
    updateWelcomeMessage();
    
    // Add loading screen to main page if not present
    if (!document.getElementById('loadingScreen')) {
        const loadingHTML = `
            <div id="loadingScreen" class="pixel-loading">
                <div class="loading-content">
                    <div class="pixel-loader"></div>
                    <h3 class="loading-title">LOADING ADVENTURE...</h3>
                    <div class="loading-bar">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                    <p class="loading-text" id="loadingText">Initializing pixel engine...</p>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', loadingHTML);
    }
}

// ===== COUNTER ANIMATIONS (From Kingdom Chronicles) =====
function initCounters() {
    setTimeout(() => {
        const heroesCount = document.getElementById('heroesCount');
        const demonsSlain = document.getElementById('demonsSlain');
        const kingdomsSaved = document.getElementById('kingdomsSaved');
        
        if (heroesCount) animateCounter(heroesCount, 247);
        if (demonsSlain) animateCounter(demonsSlain, 42500);
        if (kingdomsSaved) animateCounter(kingdomsSaved, 892);
    }, 1000);
}

function animateCounter(element, target, duration = 2000) {
    const start = parseInt(element.textContent) || 0;
    const increment = target > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / (target - start)));
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        element.textContent = current.toLocaleString();
        
        if (current === target) {
            clearInterval(timer);
        }
    }, stepTime);
}

// ===== TERMS PAGE (Keep your logic, add working validation) =====
function initTermsPage() {
    const termsBox = document.querySelector('.scroll-box');
    const continueBtn = document.getElementById('continueBtn');
    const agreeTerms = document.getElementById('agreeTerms');
    const agreeData = document.getElementById('agreeData');
    
    if (termsBox) {
        termsBox.addEventListener('scroll', function() {
            const scrollPercent = (termsBox.scrollTop + termsBox.clientHeight) / termsBox.scrollHeight;
            
            if (scrollPercent > 0.9 && !agreeTerms.checked) {
                // Auto-check terms when scrolled to bottom
                agreeTerms.checked = true;
                updateContinueButton();
                showToast('📜 Terms scrolled to bottom!');
            }
        });
        
        // Checkbox handlers - using Kingdom Chronicles logic
        agreeTerms?.addEventListener('change', updateContinueButton);
        agreeData?.addEventListener('change', updateContinueButton);
        
        // Initialize button state
        updateContinueButton();
    }
}

function updateContinueButton() {
    const agreeTerms = document.getElementById('agreeTerms');
    const agreeData = document.getElementById('agreeData');
    const continueBtn = document.getElementById('continueBtn');
    
    if (continueBtn) {
        const allRequiredAccepted = agreeTerms?.checked && agreeData?.checked;
        continueBtn.disabled = !allRequiredAccepted;
        
        if (allRequiredAccepted) {
            continueBtn.innerHTML = '<span class="btn-icon">▶️</span><span class="btn-text">CONTINUE</span>';
            continueBtn.classList.add('pixel-btn-primary');
            continueBtn.classList.remove('pixel-btn-secondary');
        } else {
            continueBtn.innerHTML = '<span class="btn-icon">🔒</span><span class="btn-text">ACCEPT TERMS</span>';
            continueBtn.classList.remove('pixel-btn-primary');
            continueBtn.classList.add('pixel-btn-secondary');
        }
    }
}

// Use Kingdom Chronicles' proceed logic
function proceedToLogin() {
    // Save acceptance to localStorage
    localStorage.setItem('termsAccepted', 'true');
    localStorage.setItem('termsAcceptedDate', new Date().toISOString());
    
    // Show loading screen
    showLoadingScreen();
    
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
}

// ===== LOGIN PAGE (Using Kingdom Chronicles working logic) =====
function initLoginPage() {
    // Password toggle functionality
    setupPasswordToggles();
    
    // Check if terms were accepted
    if (!localStorage.getItem('acceptedTerms') && !localStorage.getItem('termsAccepted')) {
        showToast('⚠️ Please accept terms first!');
        // Show loading screen and redirect to game
        showLoadingScreen();
        setTimeout(() => {
        window.location.href = 'main.html';
        }, 1500);
    }
    
    // Setup form submissions
    setupLoginForm();
    setupRegisterForm();
}

function setupLoginForm() {
    const loginForm = document.getElementById('loginFormData');
    if (!loginForm) return;
    
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        playSound('click');
        
        const username = document.getElementById('loginUsername')?.value;
        const password = document.getElementById('loginPassword')?.value;
        
        // Basic validation
        if (!username || !password) {
            showToast('⚠️ FILL ALL FIELDS');
            return;
        }
        
        // Show loading
        showLoading(true);
        
        try {
            // Simulate API delay (mock data)
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Demo accounts (from Kingdom Chronicles)
            const demoAccounts = [
                { username: 'admin', password: 'admin123' },
                { username: 'player1', password: 'player123' },
                { username: 'pixelmaster', password: 'pixel123' },
                { username: 'adventurer', password: 'adventure123' }
            ];
            
            const isValid = demoAccounts.some(account => 
                account.username === username && account.password === password
            );
            
            if (isValid) {
                // Save session
                const sessionData = {
                    session_id: 'pixel_session_' + Date.now(),
                    username: username,
                    role: 'player'
                };
                
                localStorage.setItem('session_id', sessionData.session_id);
                localStorage.setItem('username', sessionData.username);
                localStorage.setItem('role', sessionData.role);
                localStorage.setItem('is_guest', 'false');
                
                currentUser = sessionData;
                
                showToast(`🎮 WELCOME, ${sessionData.username}!`);
                celebrateLogin();
                
                // Redirect to game
                setTimeout(() => {
                    window.location.href = 'main.html';
                }, 2000);
            } else {
                // Check for mock registered users
                const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
                const user = registeredUsers.find(u => u.username === username && u.password === password);
                
                if (user) {
                    // Save session for registered user
                    const sessionData = {
                        session_id: 'user_session_' + Date.now(),
                        username: username,
                        role: 'player'
                    };
                    
                    localStorage.setItem('session_id', sessionData.session_id);
                    localStorage.setItem('username', sessionData.username);
                    localStorage.setItem('role', sessionData.role);
                    localStorage.setItem('is_guest', 'false');
                    
                    currentUser = sessionData;
                    
                    showToast(`🎮 WELCOME BACK, ${sessionData.username}!`);
                    celebrateLogin();
                    
                    // Show loading screen and redirect to game
                    showLoadingScreen();
                    setTimeout(() => {
                    window.location.href = 'main.html';
                    }, 1500);

                } else {
                    throw new Error('Invalid credentials');
                }
            }
            
        } catch (error) {
            showToast('❌ Invalid username or password');
            playSound('error');
        } finally {
            showLoading(false);
        }
    });
}

function setupRegisterForm() {
    const registerForm = document.getElementById('registerFormData');
    if (!registerForm) return;
    
    // Real-time validation
    setupRealTimeValidation();
    
    registerForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        playSound('click');
        
        if (!validateUsername() || !validatePassword() || !validateConfirmPassword()) {
            showToast('⚠️ FIX VALIDATION ERRORS');
            return;
        }
        
        const username = document.getElementById('regUsername')?.value;
        const email = document.getElementById('regEmail')?.value || null;
        const password = document.getElementById('regPassword')?.value;
        
        if (!username || !password) {
            showToast('⚠️ USERNAME & PASSWORD REQUIRED');
            return;
        }
        
        showLoading(true);
        
        try {
            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Check if username is taken
            const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
            const existingUser = registeredUsers.find(u => u.username === username);
            
            if (existingUser) {
                throw new Error('Username already taken');
            }
            
            // Create new user
            const newUser = {
                id: Date.now(),
                username: username,
                email: email,
                password: password, // In real app, this should be hashed
                created_at: new Date().toISOString(),
                level: 1,
                coins: 100,
                xp: 0
            };
            
            // Save to localStorage
            registeredUsers.push(newUser);
            localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
            
            // Create session
            const sessionData = {
                session_id: 'user_session_' + Date.now(),
                username: username,
                role: 'player'
            };
            
            localStorage.setItem('session_id', sessionData.session_id);
            localStorage.setItem('username', sessionData.username);
            localStorage.setItem('role', sessionData.role);
            localStorage.setItem('user_email', email || '');
            localStorage.setItem('is_guest', 'false');
            
            currentUser = sessionData;
            
            showToast(`✨ ACCOUNT CREATED! WELCOME, ${sessionData.username}!`);
            celebrateRegistration();
            
            // Show loading screen and redirect to game
            showLoadingScreen();
            setTimeout(() => {
            window.location.href = 'main.html';
            }, 1500);
            
        } catch (error) {
            showToast(`❌ ${error.message}`);
            playSound('error');
        } finally {
            showLoading(false);
        }
    });
}

// Keep your existing validation functions (they're good!)
function validateUsername() {
    const username = document.getElementById('regUsername');
    const feedback = document.getElementById('usernameFeedback');
    
    if (!username || !feedback) return false;
    
    const value = username.value.trim();
    
    if (value.length < 3) {
        feedback.textContent = 'TOO SHORT (MIN 3)';
        feedback.className = 'pixel-input-feedback invalid';
        return false;
    }
    
    if (value.length > 20) {
        feedback.textContent = 'TOO LONG (MAX 20)';
        feedback.className = 'pixel-input-feedback invalid';
        return false;
    }
    
    const usernameRegex = /^[a-zA-Z0-9_]+$/;
    if (!usernameRegex.test(value)) {
        feedback.textContent = 'LETTERS, NUMBERS, _ ONLY';
        feedback.className = 'pixel-input-feedback invalid';
        return false;
    }
    
    // Check if username is taken
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    if (registeredUsers.some(u => u.username === value)) {
        feedback.textContent = 'USERNAME TAKEN';
        feedback.className = 'pixel-input-feedback invalid';
        return false;
    }
    
    feedback.textContent = 'USERNAME AVAILABLE ✓';
    feedback.className = 'pixel-input-feedback valid';
    return true;
}

// Keep all your existing functions for:
// - validatePassword
// - updateRequirement
// - validateConfirmPassword
// - setupRealTimeValidation
// - checkUsernameAvailability (can be removed since we check in validateUsername)

// ===== SESSION MANAGEMENT =====
function checkSession() {
    const sessionId = localStorage.getItem('session_id');
    const username = localStorage.getItem('username');
    
    if (sessionId && username) {
        currentUser = {
            session_id: sessionId,
            username: username,
            role: localStorage.getItem('role') || 'player'
        };
        
        // If already logged in on login page, redirect
        if (window.location.pathname.includes('login.html')) {
            showToast(`⚔️ ALREADY LOGGED IN AS ${currentUser.username}`);
            setTimeout(() => {
                window.location.href = 'main.html';
            }, 1500);
        }
        
        // If on main page, update welcome message
        if (window.location.pathname.includes('main.html')) {
            updateWelcomeMessage();
        }
    }
}

function updateWelcomeMessage() {
    const username = localStorage.getItem('username') || 'Adventurer';
    const welcomeElement = document.querySelector('.game-welcome h3');
    
    if (welcomeElement) {
        welcomeElement.textContent = `WELCOME, ${username.toUpperCase()}!`;
    }
    
    // Update stats if available
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const currentUserData = registeredUsers.find(u => u.username === username);
    
    if (currentUserData) {
        const levelDisplay = document.querySelector('.stat-display:nth-child(1) .stat-value');
        const coinsDisplay = document.querySelector('.stat-display:nth-child(2) .stat-value');
        const xpDisplay = document.querySelector('.stat-display:nth-child(3) .stat-value');
        
        if (levelDisplay) levelDisplay.textContent = currentUserData.level || 1;
        if (coinsDisplay) coinsDisplay.textContent = currentUserData.coins || 0;
        if (xpDisplay) xpDisplay.textContent = `${currentUserData.xp || 0}/100`;
    }
}

// ===== GUEST LOGIN (Using Kingdom Chronicles approach) =====
function guestLogin() {
    playSound('click');
    
    // Create guest session
    const guestData = {
        session_id: 'guest_session_' + Date.now(),
        username: 'GUEST_' + Math.floor(Math.random() * 10000),
        role: 'guest',
        is_guest: true
    };
    
    // Save to localStorage
    localStorage.setItem('session_id', guestData.session_id);
    localStorage.setItem('username', guestData.username);
    localStorage.setItem('role', guestData.role);
    localStorage.setItem('is_guest', 'true');
    localStorage.setItem('guest_id', guestData.session_id);
    
    currentUser = guestData;
    
    showToast('🎭 WELCOME, GUEST ADVENTURER!');
    
    // Show loading screen and redirect
    showLoadingScreen();
    setTimeout(() => {
        window.location.href = 'main.html';
    }, 1500);
}

// ===== NAVIGATION & UTILITIES =====
function goBack() {
    playSound('click');
    
    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = 'index.html';
    }
}

function switchTab(tabName) {
    playSound('click');
    
    // Get all elements
    const loginTab = document.getElementById('loginTab');
    const registerTab = document.getElementById('registerTab');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (!loginTab || !registerTab || !loginForm || !registerForm) return;
    
    if (tabName === 'login') {
        // Activate login
        loginTab.classList.add('active');
        registerTab.classList.remove('active');
        loginForm.classList.add('active');
        registerForm.classList.remove('active');
    } else {
        // Activate register
        registerTab.classList.add('active');
        loginTab.classList.remove('active');
        registerForm.classList.add('active');
        loginForm.classList.remove('active');
    }
}

function showForgotPassword() {
    playSound('click');
    showToast('📧 CONTACT SUPPORT TO RESET PASSWORD');
}

// ===== KINGDOM CHRONICLES LOADING SCREEN =====
function showLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    const progressFill = document.getElementById('progressFill');
    const loadingText = document.getElementById('loadingText');
    
    if (!loadingScreen || !progressFill || !loadingText) {
        console.warn('Loading screen elements not found');
        return;
    }
    
    // Show loading screen
    loadingScreen.style.display = 'flex';
    
    // Custom loading messages for Pixel Adventure
    const loadingMessages = [
        'Initializing pixel engine...',
        'Loading sprites...',
        'Generating world...',
        'Almost ready...'
    ];
    
    // Change loading text every 500ms
    let currentMessage = 0;
    const interval = setInterval(() => {
        if (currentMessage < loadingMessages.length) {
            loadingText.textContent = loadingMessages[currentMessage];
            currentMessage++;
        } else {
            clearInterval(interval);
        }
    }, 500);
    
    // Animate progress bar
    let currentProgress = 0;
    const progressInterval = setInterval(() => {
        currentProgress += Math.random() * 15;
        if (currentProgress >= 100) {
            currentProgress = 100;
            clearInterval(progressInterval);
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }
        progressFill.style.width = `${currentProgress}%`;
    }, 200);
}

// ===== UI HELPERS =====
function showLoading(show) {
    const loading = document.getElementById('loadingScreen');
    if (loading) {
        if (show) {
            loading.style.display = 'flex';
            // Animate the progress bar
            const progress = loading.querySelector('.loading-progress');
            if (progress) {
                progress.style.width = '0%';
                setTimeout(() => {
                    progress.style.width = '100%';
                }, 10);
            }
        } else {
            loading.style.display = 'none';
        }
    }
}

// Keep all your existing functions for:
// - showToast
// - playSound
// - createPixelParticles
// - createCelebrationParticle
// - setupKeyboardShortcuts
// - celebrateLogin
// - celebrateRegistration
// - setupPasswordToggles
// - togglePassword

// ===== MAIN PAGE FUNCTIONS =====
function startGame() {
    const toast = document.createElement('div');
    toast.className = 'pixel-toast';
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">🎮</span>
            <span class="toast-text">GAME STARTING SOON...</span>
        </div>
    `;
    document.body.appendChild(toast);
    toast.style.display = 'flex';
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function logout() {
    // Clear all session data
    localStorage.removeItem('session_id');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    localStorage.removeItem('is_guest');
    localStorage.removeItem('guest_id');
    localStorage.removeItem('user_email');
    
    // Show logout message
    showToast('👋 Logged out successfully!');
    
    // Redirect to login
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
}

// ===== ENHANCEMENTS =====
// Add page transition
document.body.style.opacity = '0';
document.body.style.transition = 'opacity 0.5s ease-in-out';

window.addEventListener('load', () => {
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// Add some console art for fun
console.log(`
%c
  _____  _  _        ___   __   __        __   ___  
 |_   _|| |(_)      / _ \\  \\ \\ / /       /  \\ |   \\ 
   | |  | || |_____| /_\\ |  \\   /  _____ | () || |) |
   |_|  |_||_|_____|\\___/    |_|  |_____| \\__/ |___/ 
                                                     
%c✨ Pixel Adventure - Earth Tone Edition ✨
%cUsing Enhanced Kingdom Chronicles Logic 🎮
%cReady for adventure! Login: admin/admin123 or player1/player123
`, 
'color: #8b5a2b; font-family: monospace; font-size: 12px;',
'color: #d4a574; font-size: 14px; font-weight: bold;',
'color: #6b8c42; font-size: 12px;',
'color: #a67c52; font-size: 11px;'
);